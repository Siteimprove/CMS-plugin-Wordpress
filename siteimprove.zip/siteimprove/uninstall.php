<?php
/**
 * If this file is called directly, abort.
 *
 * @package Siteimprove
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
